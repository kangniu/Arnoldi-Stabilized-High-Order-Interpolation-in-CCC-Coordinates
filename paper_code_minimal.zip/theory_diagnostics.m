function rows = theory_diagnostics(outputDir)
%THEORY_DIAGNOSTICS Floating-point sampled diagnostics; not certified bounds.
if nargin < 1, outputDir = fullfile(fileparts(mfilename('fullpath')),'runtime_results'); end
if ~isfolder(outputDir), mkdir(outputDir); end
addpath(fullfile(fileparts(mfilename('fullpath')),'common'));
caseNames = {'example1_degree15','example1_degree35','example2_noise_degree19','example3_helmholtz_degree23'};
ms = [8,18,10,12]; rows = struct([]);
for j = 1:4
    m = ms(j); t = cheb_lobatto_nodes(m); s = linspace(0,1,200).';
    centerIndex = closest_center_index(t,0.5);
    if j == 1, centerIndex = 4; end
    if j == 4
        curve = helmholtz_curve_setup(500,8,3141); train = helmholtz_curve_sample(curve,t);
    else
        curve = synthetic_curve_setup(1000,10,1137);
        if j == 3, train = synthetic_curve_sample(curve,t,struct('noiseLevel',1e-10,'noiseSeed',2718));
        else, train = synthetic_curve_sample(curve,t); end
    end
    chart = build_chart('ccc',train.U{centerIndex});
    coord = map_chart_data(chart,train.U,train.Delta);
    arn = cva_arnoldi(t,2*m-1); Y = [coord.X;coord.Xdot]; A = arn.Q\Y;
    [~,~,VH] = eval_augmented_basis(t,arn.H);
    [Phi,~,~] = eval_augmented_basis(s,arn.H);
    % VH is recomputed by floating-point recurrence. Lambda is a grid maximum.
    cardinal = Phi/VH;
    rows(j).Case = caseNames{j}; rows(j).m = m; rows(j).Degree = 2*m-1;
    rows(j).DeltaH2 = norm(VH-arn.Q,2);
    rows(j).RelativeDeltaH2 = norm(VH-arn.Q,2)/sqrt(m);
    rows(j).EtaQ = arn.etaQ;
    rows(j).LambdaHGrid2 = max(vecnorm(cardinal,2,2));
    rows(j).RelativeSolveResidualF = norm(Y-arn.Q*A,'fro')/norm(Y,'fro');
    rows(j).MinSigmaVH = min(svd(VH));
    rows(j).CondVH = cond(VH);
    rows(j).GridPoints = numel(s);
    rows(j).MaxPhi2 = max(vecnorm(Phi,2,2));
    rows(j).MaxChartKappa2 = max(coord.kappa2);
    rows(j).MaxChartKappaF = max(coord.kappaF);
end
writetable(struct2table(rows),fullfile(outputDir,'theory_diagnostics.csv'));
save(fullfile(outputDir,'theory_diagnostics.mat'),'rows');
disp(struct2table(rows));
end
