function results = runtime_benchmark(outputDir)
%RUNTIME_BENCHMARK Reproducible, computation-only timing of submitted methods.
% Run with MATLAB -batch "runtime_benchmark('path/to/results')".
% The common/ directory is an unmodified copy of the submitted implementation.
% Timing kernels below remove diagnostics, plotting, and error validation only.
% They preserve the submitted dense complete-QR CCC and normal finite difference.

if nargin < 1, outputDir = fullfile(fileparts(mfilename('fullpath')), 'runtime_results'); end
if ~isfolder(outputDir), mkdir(outputDir); end
addpath(fullfile(fileparts(mfilename('fullpath')), 'common'));
warmups = 2; repeats = 7; nEval = 200;
metadata.matlabVersion = version;
metadata.release = version('-release');
metadata.computer = computer;
metadata.timestamp = char(datetime('now','Format','yyyy-MM-dd HH:mm:ss'));
metadata.blas = version('-blas');
metadata.lapack = version('-lapack');
metadata.warmups = warmups; metadata.repeats = repeats;
metadata.threads = maxNumCompThreads;
metadata.evalPoints = nEval;
metadata.syntheticSeed = 1137; metadata.noiseSeed = 2718; metadata.helmholtzSeed = 3141;
metadata.cpu = getenv('PROCESSOR_IDENTIFIER');
try, metadata.memory = memory; catch, metadata.memory = []; end
fid = fopen(fullfile(outputDir,'metadata.json'),'w');
fprintf(fid,'%s',jsonencode(metadata,PrettyPrint=true)); fclose(fid);
warningState = warning;
cleanup = onCleanup(@() warning(warningState)); %#ok<NASGU>
warning('off','MATLAB:nearlySingularMatrix');
warning('off','MATLAB:singularMatrix');
methods = make_method_list('full');
methods(end+1) = struct('name','ccc_lagrange_direct','label','CCC + direct Lagrange','coordType','ccc','algebra','lagrange_direct');
methods(end+1) = struct('name','ccc_va','label','CCC-V+A','coordType','ccc','algebra','va');
caseNames = {'example1_degree15','example1_degree35','example2_noise_degree19','example3_helmholtz_degree23'};
ms = [8,18,10,12];
raw = struct([]); summary = struct([]); charts = struct([]); validation = struct([]);
rr = 0; ss = 0; cc = 0; vv = 0;
for caseIndex = 1:numel(caseNames)
    m = ms(caseIndex); t = cheb_lobatto_nodes(m); s = linspace(0,1,nEval).';
    centerIndex = closest_center_index(t,0.5);
    if caseIndex == 1, centerIndex = 4; end
    if caseIndex == 4
        curve = helmholtz_curve_setup(500,8,3141);
        train = helmholtz_curve_sample(curve,t);
    else
        curve = synthetic_curve_setup(1000,10,1137);
        if caseIndex == 3
            train = synthetic_curve_sample(curve,t,struct('noiseLevel',1e-10,'noiseSeed',2718));
        else
            train = synthetic_curve_sample(curve,t);
        end
    end
    Uref = train.U{centerIndex}; [n,p] = size(Uref);
    for ct = {'raw','maxvol','ccc'}
        chart = build_chart(ct{1},Uref);
        coord = map_chart_data(chart,train.U,train.Delta);
        for i = 1:m
            cc = cc+1;
            charts(cc).Case = caseNames{caseIndex};
            charts(cc).Chart = ct{1}; charts(cc).Node = i; charts(cc).t = t(i);
            charts(cc).Kappa2 = coord.kappa2(i); charts(cc).KappaF = coord.kappaF(i);
            charts(cc).SigmaMin = coord.sigmaMin(i); charts(cc).p = p;
        end
    end
    % Two untimed warmups per method. Data are generated once and shared.
    fprintf('Starting %s: n=%d p=%d m=%d M=%d\n',caseNames{caseIndex},n,p,m,nEval);
    for j = 1:numel(methods)
        for k = 1:warmups
            [~,lastU,lastX] = execute_once(methods(j),t,train,s,centerIndex);
        end
        % Validate the computation-only kernel against the submitted routines.
        [refU,refX] = reference_output(methods(j),t,train,s,centerIndex);
        vv = vv+1;
        validation(vv).Case = caseNames{caseIndex}; validation(vv).Method = methods(j).name;
        validation(vv).RelativeCoordinateDifference = norm(lastX-refX,'fro') / max(1,norm(refX,'fro'));
        validation(vv).RelativeReconstructionDifference = norm(lastU-refU,'fro') / max(1,norm(refU,'fro'));
        assert(validation(vv).RelativeCoordinateDifference < 1e-13,'Timing and original interpolation differ');
        assert(validation(vv).RelativeReconstructionDifference < 1e-13,'Timing and original reconstruction differ');
    end
    % Rotate the order between repeats to reduce order/drift effects.
    timing = zeros(repeats,numel(methods),4);
    for k = 1:repeats
        order = circshift(1:numel(methods),[0,k-1]);
        for j = order
            elapsed = execute_once(methods(j),t,train,s,centerIndex);
            timing(k,j,:) = elapsed;
            rr = rr+1;
            raw(rr).Case = caseNames{caseIndex}; raw(rr).Method = methods(j).name;
            raw(rr).Repeat = k; raw(rr).MappingSeconds = elapsed(1);
            raw(rr).PolynomialSeconds = elapsed(2); raw(rr).ReconstructionSeconds = elapsed(3);
            raw(rr).TotalSeconds = elapsed(4);
        end
    end
    for j = 1:numel(methods)
        ts = squeeze(timing(:,j,:));
        ss = ss+1;
        summary(ss).Case = caseNames{caseIndex}; summary(ss).Method = methods(j).name;
        summary(ss).n = n; summary(ss).p = p; summary(ss).m = m; summary(ss).EvalPoints = nEval;
        summary(ss).MedianMappingSeconds = median(ts(:,1));
        summary(ss).MedianPolynomialSeconds = median(ts(:,2));
        summary(ss).MedianReconstructionSeconds = median(ts(:,3));
        summary(ss).MedianTotalSeconds = median(ts(:,4));
        summary(ss).MinimumTotalSeconds = min(ts(:,4));
        summary(ss).MaximumTotalSeconds = max(ts(:,4));
        fprintf('  %-22s total %.6f s (min %.6f, max %.6f)\n', methods(j).name,median(ts(:,4)),min(ts(:,4)),max(ts(:,4)));
    end
    writetable(struct2table(raw),fullfile(outputDir,'runtime_raw.csv'));
    writetable(struct2table(summary),fullfile(outputDir,'runtime_summary.csv'));
    writetable(struct2table(charts),fullfile(outputDir,'chart_norms_nodes.csv'));
    writetable(struct2table(validation),fullfile(outputDir,'runtime_validation.csv'));
end
results = struct('metadata',metadata,'raw',raw,'summary',summary,'charts',charts,'validation',validation);
save(fullfile(outputDir,'runtime_results.mat'),'results');
fprintf('Benchmark finished.\n');
end

function [elapsed,Ulast,Xeval] = execute_once(method,t,train,s,centerIndex)
% Stage clocks surround algorithmic work only; total includes stage overhead.
totalClock = tic; stageClock = tic;
Uref = train.U{centerIndex};
[n,p] = size(Uref); m = numel(t);
isHermite = ~ismember(method.algebra,{'va','lagrange_direct'});
if strcmp(method.coordType,'normal')
    X = zeros(m,n*p); Xdot = zeros(m,n*p); h = 1e-6;
    for i = 1:m
        Xi = grassmann_log(Uref,train.U{i});
        Up = orthonormalize(train.U{i}+h*train.Delta{i});
        Um = orthonormalize(train.U{i}-h*train.Delta{i});
        Xidot = (grassmann_log(Uref,Up)-grassmann_log(Uref,Um))/(2*h);
        X(i,:) = Xi(:).'; Xdot(i,:) = Xidot(:).';
    end
    coord = struct('Uref',Uref,'n',n,'p',p);
else
    chart = build_chart(method.coordType,Uref);
    X = zeros(m,(n-p)*p); Xdot = zeros(m,(n-p)*p);
    for i = 1:m
        V = apply_chart_transform(chart,train.U{i});
        V1 = V(1:p,:); Xi = V(p+1:end,:)/V1;
        X(i,:) = Xi(:).';
        if isHermite
            W = apply_chart_transform(chart,train.Delta{i});
            Xidot = (W(p+1:end,:)-Xi*W(1:p,:))/V1;
            Xdot(i,:) = Xidot(:).';
        end
    end
end
mappingTime = toc(stageClock); stageClock = tic;
switch method.algebra
    case 'direct'
        degree = 2*m-1; C = confluent_vandermonde(t,degree);
        A = C\[X;Xdot]; Phi = vandermonde_values(s,degree); Xeval = Phi*A;
    case 'cva'
        [Q,H] = arnoldi_core(t,true);
        A = Q\[X;Xdot]; [Phi,~,~] = eval_augmented_basis(s,H); Xeval = Phi*A;
    case 'lagrange_direct'
        V = vandermonde_values(t,m-1); A = V\X;
        Phi = vandermonde_values(s,m-1); Xeval = Phi*A;
    case 'va'
        [Q,H] = arnoldi_core(t,false); A = Q\X;
        Phi = eval_arnoldi_basis(s,H); Xeval = Phi*A;
end
polynomialTime = toc(stageClock); stageClock = tic;
for j = 1:numel(s)
    if strcmp(method.coordType,'normal')
        Ulast = reconstruct_normal_point(coord,Xeval(j,:));
    else
        Ulast = reconstruct_chart_point(chart,Xeval(j,:));
    end
end
reconstructionTime = toc(stageClock);
elapsed = [mappingTime,polynomialTime,reconstructionTime,toc(totalClock)];
end

function [Q,H] = arnoldi_core(t,isHermite)
% The submitted MGS-with-two-passes implementation, with no diagnostics.
t = t(:); m = numel(t); N = m*(1+isHermite); degree = N-1;
Q = zeros(N,degree+1); H = zeros(degree+1,degree);
Q(1:m,1) = 1;
for j = 1:degree
    if isHermite, v = [t.*Q(1:m,j);Q(1:m,j)+t.*Q(m+1:end,j)];
    else, v = t.*Q(:,j); end
    for pass = 1:2
        for i = 1:j
            hij = (Q(:,i).'*v)/m; H(i,j) = H(i,j)+hij; v = v-Q(:,i)*hij;
        end
    end
    hnext = norm(v)/sqrt(m); H(j+1,j) = hnext;
    assert(hnext > 100*eps,'Near breakdown of the Arnoldi process');
    Q(:,j+1) = v/hnext;
end
end

function [Ulast,Xeval] = reference_output(method,t,train,s,centerIndex)
Uref = train.U{centerIndex};
if strcmp(method.coordType,'normal')
    coord = map_normal_data(Uref,train.U,train.Delta);
else
    chart = build_chart(method.coordType,Uref);
    coord = map_chart_data(chart,train.U,train.Delta);
end
switch method.algebra
    case 'direct', Xeval = hermite_interpolate_direct(t,coord.X,coord.Xdot,s);
    case 'cva', Xeval = hermite_interpolate_cva(t,coord.X,coord.Xdot,s);
    case 'lagrange_direct', Xeval = lagrange_interpolate_direct(t,coord.X,s);
    case 'va', Xeval = lagrange_interpolate_va(t,coord.X,s);
end
if strcmp(method.coordType,'normal'), Ulast = reconstruct_normal_point(coord,Xeval(end,:));
else, Ulast = reconstruct_chart_point(chart,Xeval(end,:)); end
end
