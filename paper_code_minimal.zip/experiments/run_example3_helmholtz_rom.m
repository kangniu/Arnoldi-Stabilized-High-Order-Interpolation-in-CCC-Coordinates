function out = run_example3_helmholtz_rom(cfg)
%RUN_EXAMPLE3_HELMHOLTZ_ROM Parametric 1D Helmholtz ROM interpolation.

fprintf('\nExample 3: parametric 1D Helmholtz ROM\n');

n = 500;
p = 8;
m = 12;

curve = helmholtz_curve_setup(n, p, cfg.helmholtzSeed);
tTrain = cheb_lobatto_nodes(m);
tEval = linspace(0, 1, cfg.evalPoints).';
centerIndex = closest_center_index(tTrain, 0.5);

trainSample = helmholtz_curve_sample(curve, tTrain);
trueSample = helmholtz_curve_sample(curve, tEval);

fprintf('  Nodes m = %d, Hermite degree = %d, center k = %.4f\n', ...
    m, 2*m - 1, trainSample.k(centerIndex));

methods = make_method_list('full');
paperMethodNames = {'normal_direct', 'raw_direct', 'maxvol_direct', 'ccc_cva'};
comparison = run_hermite_comparison(tTrain, trainSample, tEval, trueSample, centerIndex, methods);
comparison.kEval = trueSample.k;
comparison.kTrain = trainSample.k;

prefix = 'example3_helmholtz_rom';
save_comparison_outputs(cfg, prefix, comparison);

if cfg.makePlots
    fullFig = fullfile(cfg.outputFigureDir, [prefix, '_full.png']);
    plot_error_only(trueSample.k, comparison.results, ...
        'Example 3, Helmholtz ROM: full comparison', fullFig, 'k');

    paperFig = fullfile(cfg.outputFigureDir, 'helmholtz_rom_error.png');
    paperResults = select_results(comparison.results, paperMethodNames);
    plot_error_only(trueSample.k, paperResults, ...
        'Example 3, Helmholtz ROM', paperFig, 'k');
    write_paper_figure_if_requested(cfg, paperFig, 'helmholtz_rom_error.png');
end

out = struct();
out.tTrain = tTrain;
out.kTrain = trainSample.k;
out.centerIndex = centerIndex;
out.comparison = comparison;
end
