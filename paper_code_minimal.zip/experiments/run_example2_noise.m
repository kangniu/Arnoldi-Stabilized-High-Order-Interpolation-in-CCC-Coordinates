function out = run_example2_noise(cfg)
%RUN_EXAMPLE2_NOISE Sensitivity to perturbed input data.

fprintf('\nExample 2: sensitivity to data perturbations\n');

n = 1000;
p = 10;
m = 10;
noiseLevel = 1e-10;

curve = synthetic_curve_setup(n, p, cfg.syntheticSeed);
tTrain = cheb_lobatto_nodes(m);
tEval = linspace(0, 1, cfg.evalPoints).';
centerIndex = closest_center_index(tTrain, 0.5);

trainSample = synthetic_curve_sample(curve, tTrain, ...
    struct('noiseLevel', noiseLevel, 'noiseSeed', cfg.noiseSeed));
trueSample = synthetic_curve_sample(curve, tEval);

fprintf('  Nodes m = %d, Hermite degree = %d, center t = %.4f, noise = %.1e\n', ...
    m, 2*m - 1, tTrain(centerIndex), noiseLevel);

methods = make_method_list('full');
paperMethodNames = {'normal_direct', 'raw_direct', 'maxvol_direct', 'ccc_cva'};
comparison = run_hermite_comparison(tTrain, trainSample, tEval, trueSample, centerIndex, methods);
comparison.noiseLevel = noiseLevel;

prefix = 'example2_noise';
save_comparison_outputs(cfg, prefix, comparison);

if cfg.makePlots
    fullFig = fullfile(cfg.outputFigureDir, [prefix, '_full.png']);
    plot_error_only(tEval, comparison.results, ...
        sprintf('Example 2, noise %.1e: full comparison', noiseLevel), fullFig, 't');

    paperFig = fullfile(cfg.outputFigureDir, 'noise_sensitivity_figure.png');
    paperResults = select_results(comparison.results, paperMethodNames);
    plot_error_only(tEval, paperResults, ...
        sprintf('Example 2, noise %.1e', noiseLevel), paperFig, 't');
    write_paper_figure_if_requested(cfg, paperFig, 'noise_sensitivity_figure.png');
end

out = struct();
out.tTrain = tTrain;
out.centerIndex = centerIndex;
out.noiseLevel = noiseLevel;
out.comparison = comparison;
end
