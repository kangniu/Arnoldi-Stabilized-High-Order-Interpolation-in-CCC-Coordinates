function out = run_example1_dual_stability(cfg)
%RUN_EXAMPLE1_DUAL_STABILITY High-order stability tests on Gr(1000,10).

fprintf('\nExample 1: high-order interpolation and dual stability\n');

n = 1000;
p = 10;
curve = synthetic_curve_setup(n, p, cfg.syntheticSeed);
tEval = linspace(0, 1, cfg.evalPoints).';
trueSample = synthetic_curve_sample(curve, tEval);

methods = make_method_list('full');
paperMethodNames = {'normal_direct', 'raw_direct', 'maxvol_direct', 'ccc_cva'};

out = struct();
out.degree15 = run_one_case(cfg, curve, trueSample, tEval, 8, 4, ...
    'example1_degree15', 'dual_stability_figure.png', methods, paperMethodNames);
out.degree35 = run_one_case(cfg, curve, trueSample, tEval, 18, [], ...
    'example1_degree35', 'dual_stability_figure2.png', methods, paperMethodNames);
end

function caseOut = run_one_case(cfg, curve, trueSample, tEval, m, centerIndex, prefix, paperFigureName, methods, paperMethodNames)
tTrain = cheb_lobatto_nodes(m);
if isempty(centerIndex)
    centerIndex = closest_center_index(tTrain, 0.5);
end
trainSample = synthetic_curve_sample(curve, tTrain);

fprintf('  Nodes m = %d, Hermite degree = %d, center t = %.4f\n', ...
    m, 2*m - 1, tTrain(centerIndex));

comparison = run_hermite_comparison(tTrain, trainSample, tEval, trueSample, centerIndex, methods);
save_comparison_outputs(cfg, prefix, comparison);

chartTable = chart_condition_table(tTrain, trainSample.U, centerIndex);
writetable(chartTable, fullfile(cfg.outputTableDir, [prefix, '_chart_condition.csv']));

if cfg.makePlots
    fullFig = fullfile(cfg.outputFigureDir, [prefix, '_full.png']);
    plot_error_orthogonality(tEval, comparison.results, ...
        sprintf('Example 1, m=%d, Hermite degree %d: full comparison', m, 2*m-1), fullFig);

    paperFig = fullfile(cfg.outputFigureDir, paperFigureName);
    paperResults = select_results(comparison.results, paperMethodNames);
    plot_error_orthogonality(tEval, paperResults, ...
        sprintf('Example 1, m=%d, Hermite degree %d', m, 2*m-1), paperFig);
    write_paper_figure_if_requested(cfg, paperFig, paperFigureName);
end

caseOut = struct();
caseOut.tTrain = tTrain;
caseOut.centerIndex = centerIndex;
caseOut.comparison = comparison;
caseOut.chartCondition = chartTable;
end
