function chart = build_chart(chartType, Uref)
%BUILD_CHART Construct a fixed Grassmann affine chart.
%
% chartType can be:
%   'raw'    first p rows are used as the affine block;
%   'maxvol' greedy maximum-volume row selection;
%   'ccc'    canonical centering by a complete QR transform of Uref.

chartType = lower(string(chartType));
[n, p] = size(Uref);

chart = struct();
chart.type = char(chartType);
chart.n = n;
chart.p = p;

switch chartType
    case "raw"
        chart.perm = 1:n;
        chart.Q = [];
    case "maxvol"
        selected = maxvol_rows(Uref);
        rest = setdiff(1:n, selected, 'stable');
        chart.perm = [selected(:).', rest(:).'];
        chart.selectedRows = selected(:);
        chart.Q = [];
    case "ccc"
        [Q, ~] = qr(Uref);
        chart.Q = Q;
        chart.perm = [];
    otherwise
        error('Unknown chart type "%s".', chartType);
end
end
