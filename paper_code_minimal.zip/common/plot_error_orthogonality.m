function plot_error_orthogonality(tEval, results, titleText, outFile)
%PLOT_ERROR_ORTHOGONALITY Two-panel plot for reconstruction and orthogonality.

fig = figure('Color', 'w', 'Position', [100, 100, 1120, 430]);
tl = tiledlayout(fig, 1, 2, 'TileSpacing', 'compact', 'Padding', 'compact');
title(tl, titleText, 'Interpreter', 'none');

nexttile;
hold on;
for i = 1:numel(results)
    style = method_plot_style(results(i).name);
    semilogy(tEval, floor_log_values(results(i).error), ...
        'Color', style.Color, 'LineStyle', style.LineStyle, ...
        'LineWidth', style.LineWidth);
end
grid on;
set(gca, 'YScale', 'log');
xlabel('t');
ylabel('relative projector error');
legend({results.label}, 'Interpreter', 'none', 'Location', 'southoutside', 'NumColumns', 2);

nexttile;
hold on;
for i = 1:numel(results)
    style = method_plot_style(results(i).name);
    semilogy(tEval, floor_log_values(results(i).orthLoss), ...
        'Color', style.Color, 'LineStyle', style.LineStyle, ...
        'LineWidth', style.LineWidth);
end
grid on;
set(gca, 'YScale', 'log');
xlabel('t');
ylabel('orthogonality loss');
legend({results.label}, 'Interpreter', 'none', 'Location', 'southoutside', 'NumColumns', 2);

if nargin >= 4 && ~isempty(outFile)
    hide_axes_toolbars(fig);
    exportgraphics(fig, outFile, 'Resolution', 300);
end
end
