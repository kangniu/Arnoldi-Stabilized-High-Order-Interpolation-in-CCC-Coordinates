function write_paper_figure_if_requested(cfg, localFigurePath, paperFigureName)
%WRITE_PAPER_FIGURE_IF_REQUESTED Copy generated figure to project root.

if cfg.writePaperFigures
    copyfile(localFigurePath, fullfile(cfg.projectRoot, paperFigureName));
end
end
