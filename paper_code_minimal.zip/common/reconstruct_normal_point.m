function U = reconstruct_normal_point(coord, xrow)
%RECONSTRUCT_NORMAL_POINT Reconstruct a Stiefel representative from log data.

X = reshape(xrow(:), coord.n, coord.p);
if any(~isfinite(X(:)))
    U = NaN(coord.n, coord.p);
    return;
end
U = grassmann_exp(coord.Uref, X);
end
