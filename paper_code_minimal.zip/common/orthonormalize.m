function U = orthonormalize(Y)
%ORTHONORMALIZE Return a deterministic thin orthonormal basis.

[U, ~] = thin_qr_positive(Y);
end
