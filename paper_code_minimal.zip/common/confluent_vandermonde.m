function C = confluent_vandermonde(t, degree)
%CONFLUENT_VANDERMONDE Hermite matrix for values followed by derivatives.

t = t(:);
m = numel(t);
C = zeros(2*m, degree + 1);
C(1:m, :) = vandermonde_values(t, degree);

for j = 2:degree+1
    C(m+1:end, j) = (j - 1) * t.^(j - 2);
end
end
