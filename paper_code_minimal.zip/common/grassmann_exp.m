function U = grassmann_exp(U0, X)
%GRASSMANN_EXP Grassmann exponential from a horizontal tangent matrix.

X = X - U0*(U0.'*X);
[A, S, B] = svd(X, 'econ');
sigma = diag(S);
C = diag(cos(sigma));
Sn = diag(sin(sigma));
U = U0*(B*C*B.') + A*Sn*B.';
end
