function arn = va_arnoldi(t, degree)
%VA_ARNOLDI Scaled Arnoldi basis for Lagrange interpolation.

t = t(:);
m = numel(t);
if degree > m - 1
    error('V+A degree %d exceeds the Lagrange data dimension %d.', degree, m - 1);
end

Q = zeros(m, degree + 1);
H = zeros(degree + 1, degree);
Q(:, 1) = ones(m, 1);

for j = 1:degree
    v = t.*Q(:, j);
    for pass = 1:2
        for i = 1:j
            hij = (Q(:, i).'*v) / m;
            H(i, j) = H(i, j) + hij;
            v = v - Q(:, i)*hij;
        end
    end
    hnext = norm(v) / sqrt(m);
    H(j + 1, j) = hnext;
    if hnext <= 100*eps
        warning('va_arnoldi:Breakdown', ...
            'Near breakdown at step %d; remaining basis columns are set to NaN.', j);
        Q(:, j+1:end) = NaN;
        break;
    end
    Q(:, j + 1) = v / hnext;
end

arn = struct();
arn.Q = Q;
arn.H = H;
arn.degree = degree;
arn.m = m;
arn.etaQ = norm((Q.'*Q)/m - eye(degree + 1), 2);
arn.condQ = cond(Q);
arn.minSubdiag = min(abs(diag(H, -1)));
end
