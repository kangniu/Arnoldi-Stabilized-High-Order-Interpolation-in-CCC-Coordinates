function methods = make_method_list(kind)
%MAKE_METHOD_LIST Methods used in the numerical comparisons.

if nargin < 1
    kind = 'full';
end
kind = lower(char(kind));

allMethods = {
    'normal_direct', 'Normal + direct Hermite', 'normal', 'direct', true;
    'raw_direct',    'Raw fixed block + direct Hermite', 'raw', 'direct', true;
    'maxvol_direct', 'Maxvol row selection + direct Hermite', 'maxvol', 'direct', true;
    'ccc_direct',    'CCC + direct Hermite', 'ccc', 'direct', false;
    'normal_cva',    'Normal + CV+A', 'normal', 'cva', false;
    'raw_cva',       'Raw fixed block + CV+A', 'raw', 'cva', false;
    'maxvol_cva',    'Maxvol row selection + CV+A', 'maxvol', 'cva', false;
    'ccc_cva',       'CCC-CV+A', 'ccc', 'cva', true;
    };

switch kind
    case 'paper'
        keep = cell2mat(allMethods(:, 5));
    case 'full'
        keep = true(size(allMethods, 1), 1);
    otherwise
        error('Unknown method-list kind "%s".', kind);
end

rows = allMethods(keep, :);
methods = struct('name', {}, 'label', {}, 'coordType', {}, 'algebra', {});
for i = 1:size(rows, 1)
    methods(i).name = rows{i, 1};
    methods(i).label = rows{i, 2};
    methods(i).coordType = rows{i, 3};
    methods(i).algebra = rows{i, 4};
end
end
