function T = chart_condition_table(t, Ucell, centerIndex)
%CHART_CONDITION_TABLE Frobenius chart condition for raw, maxvol, and CCC.

Uref = Ucell{centerIndex};
charts = {build_chart('raw', Uref), build_chart('maxvol', Uref), build_chart('ccc', Uref)};
names = {'RawFixedBlock', 'MaxvolRowSelection', 'CCCCentered'};

data = zeros(numel(t), numel(charts));
for j = 1:numel(charts)
    coord = map_chart_data(charts{j}, Ucell, zero_tangent_cells(Ucell));
    data(:, j) = coord.kappaF;
end

T = table(t(:), data(:, 1), data(:, 2), data(:, 3), ...
    'VariableNames', [{'t'}, names]);
end
