function [U, Delta, R] = horizontal_lift_from_full_rank(Y, Ydot)
%HORIZONTAL_LIFT_FROM_FULL_RANK Convert full-rank matrix data to Stiefel data.
%
% If Y = U R is a thin QR factorization, the Grassmann tangent represented
% by Ydot has horizontal lift Delta = (I-UU') Ydot R^{-1}.

[U, R] = thin_qr_positive(Y);
Delta = (Ydot - U*(U.'*Ydot)) / R;
Delta = Delta - U*(U.'*Delta);
end
