function style = method_plot_style(methodName)
%METHOD_PLOT_STYLE Fixed high-contrast plotting style by method name.

style = struct();
style.Color = [0.15, 0.15, 0.15];
style.LineStyle = '-';
style.LineWidth = 1.7;

switch lower(char(methodName))
    case 'normal_direct'
        style.Color = [0.000, 0.250, 0.750];
        style.LineStyle = '--';
        style.LineWidth = 1.8;
    case 'raw_direct'
        style.Color = [0.800, 0.120, 0.120];
        style.LineStyle = '-';
        style.LineWidth = 1.9;
    case 'maxvol_direct'
        style.Color = [0.000, 0.500, 0.180];
        style.LineStyle = '-.';
        style.LineWidth = 1.9;
    case 'ccc_cva'
        style.Color = [0.000, 0.000, 0.000];
        style.LineStyle = '-';
        style.LineWidth = 2.2;
    case 'ccc_direct'
        style.Color = [0.450, 0.450, 0.450];
        style.LineStyle = ':';
        style.LineWidth = 1.8;
    case 'normal_cva'
        style.Color = [0.000, 0.620, 0.720];
        style.LineStyle = '--';
        style.LineWidth = 1.7;
    case 'raw_cva'
        style.Color = [0.950, 0.550, 0.150];
        style.LineStyle = ':';
        style.LineWidth = 1.8;
    case 'maxvol_cva'
        style.Color = [0.350, 0.700, 0.250];
        style.LineStyle = ':';
        style.LineWidth = 1.8;
end
end
