function T = results_curve_table(results)
%RESULTS_CURVE_TABLE Long table of pointwise errors and orthogonality loss.

t = [];
method = {};
label = {};
coordType = {};
algebra = {};
err = [];
orth = [];

for i = 1:numel(results)
    nEval = numel(results(i).tEval);
    t = [t; results(i).tEval(:)]; %#ok<AGROW>
    method = [method; repmat({results(i).name}, nEval, 1)]; %#ok<AGROW>
    label = [label; repmat({results(i).label}, nEval, 1)]; %#ok<AGROW>
    coordType = [coordType; repmat({results(i).coordType}, nEval, 1)]; %#ok<AGROW>
    algebra = [algebra; repmat({results(i).algebra}, nEval, 1)]; %#ok<AGROW>
    err = [err; results(i).error(:)]; %#ok<AGROW>
    orth = [orth; results(i).orthLoss(:)]; %#ok<AGROW>
end

T = table(t, method, label, coordType, algebra, err, orth, ...
    'VariableNames', {'t', 'method', 'label', 'coordType', 'algebra', ...
    'relativeProjectorError', 'orthogonalityLoss'});
end
