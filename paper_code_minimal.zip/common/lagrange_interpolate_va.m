function [Xeval, alg] = lagrange_interpolate_va(t, X, s)
%LAGRANGE_INTERPOLATE_VA Vandermonde-with-Arnoldi interpolation.

t = t(:);
s = s(:);
degree = numel(t) - 1;
arn = va_arnoldi(t, degree);
A = arn.Q \ X;
Phi = eval_arnoldi_basis(s, arn.H);
Xeval = Phi * A;

alg = struct();
alg.type = 'va';
alg.degree = degree;
alg.condSystem = NaN;
alg.coeffNormF = norm(A, 'fro');
alg.etaQ = arn.etaQ;
alg.condQ = arn.condQ;
alg.minSubdiag = arn.minSubdiag;
alg.basisGrowth = max(vecnorm(Phi, 2, 2));
alg.recurrenceDiagnostic = NaN;
alg.H = arn.H;
end
