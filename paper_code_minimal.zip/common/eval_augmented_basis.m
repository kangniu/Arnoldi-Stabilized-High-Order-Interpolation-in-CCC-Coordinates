function [PhiValue, PhiDeriv, PhiAug] = eval_augmented_basis(s, H)
%EVAL_AUGMENTED_BASIS Evaluate CV+A basis and derivative basis at points s.

s = s(:);
M = numel(s);
degree = size(H, 2);
PhiAug = zeros(2*M, degree + 1);
PhiAug(:, 1) = [ones(M, 1); zeros(M, 1)];

for j = 1:degree
    top = PhiAug(1:M, j);
    bot = PhiAug(M+1:end, j);
    v = [s.*top; top + s.*bot] - PhiAug(:, 1:j)*H(1:j, j);
    hnext = H(j + 1, j);
    if abs(hnext) <= realmin
        PhiAug(:, j+1:end) = NaN;
        break;
    end
    PhiAug(:, j + 1) = v / hnext;
end

PhiValue = PhiAug(1:M, :);
PhiDeriv = PhiAug(M+1:end, :);
end
