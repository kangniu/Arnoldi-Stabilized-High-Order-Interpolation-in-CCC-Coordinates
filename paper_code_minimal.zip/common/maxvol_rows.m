function selected = maxvol_rows(A, tol, maxIter)
%MAXVOL_ROWS Greedy maximum-volume row subset for a tall full-rank matrix.
%
% The routine starts from QR-pivoted rows and performs the standard maxvol
% row-exchange iteration until all interpolation coefficients have magnitude
% at most 1+tol.  It is intended for the small p used in these experiments.

if nargin < 2 || isempty(tol)
    tol = 1e-2;
end
if nargin < 3 || isempty(maxIter)
    maxIter = 500;
end

[n, p] = size(A);
if n < p
    error('maxvol_rows:Shape', 'The input matrix must have at least p rows.');
end

[~, ~, piv] = qr(A.', 'vector');
selected = piv(1:p);

for iter = 1:maxIter
    B = A(selected, :);
    if rcond(B) < eps
        break;
    end
    C = A / B;
    [maxVal, linearIndex] = max(abs(C(:)));
    if maxVal <= 1 + tol
        return;
    end
    [rowIndex, colIndex] = ind2sub(size(C), linearIndex);
    selected(colIndex) = rowIndex;
    selected = repair_duplicate_rows(A, selected);
end

warning('maxvol_rows:NoConvergence', ...
    'Maxvol row selection stopped after %d iterations.', maxIter);
end
