function t = cheb_lobatto_nodes(m)
%CHEB_LOBATTO_NODES Chebyshev-Lobatto nodes mapped to [0,1].

if m < 2
    t = 0.5;
    return;
end

j = (0:m-1).';
t = 0.5 - 0.5*cos(pi*j/(m-1));
end
