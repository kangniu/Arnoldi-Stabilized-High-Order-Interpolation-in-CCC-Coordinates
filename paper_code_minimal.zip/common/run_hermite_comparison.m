function out = run_hermite_comparison(tTrain, trainSample, tEval, trueSample, centerIndex, methods)
%RUN_HERMITE_COMPARISON Evaluate all selected Hermite methods.

if nargin < 6 || isempty(methods)
    methods = make_method_list('full');
end

results = [];
for i = 1:numel(methods)
    fprintf('  %-38s', methods(i).label);
    tic;
    result = evaluate_hermite_method(methods(i), tTrain, ...
        trainSample.U, trainSample.Delta, tEval, trueSample.U, centerIndex);
    if i == 1
        results = result;
    else
        results(i) = result; %#ok<AGROW>
    end
    fprintf(' max err = %.3e, time = %.2fs\n', ...
        results(i).summary.MaxError, toc);
end

out = struct();
out.results = results;
out.summaryTable = results_summary_table(results);
out.curveTable = results_curve_table(results);
end
