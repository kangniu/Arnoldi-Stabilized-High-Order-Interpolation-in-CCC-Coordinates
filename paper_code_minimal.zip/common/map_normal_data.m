function coord = map_normal_data(Uref, Ucell, Dcell)
%MAP_NORMAL_DATA Map samples into normal coordinates at Uref.

m = numel(Ucell);
[n, p] = size(Uref);
X = zeros(m, n*p);
Xdot = zeros(m, n*p);
coordNorm = zeros(m, 1);
h = 1e-6;

for i = 1:m
    Xi = grassmann_log(Uref, Ucell{i});

    Up = orthonormalize(Ucell{i} + h*Dcell{i});
    Um = orthonormalize(Ucell{i} - h*Dcell{i});
    Xip = grassmann_log(Uref, Up);
    Xim = grassmann_log(Uref, Um);
    Xidot = (Xip - Xim) / (2*h);

    X(i, :) = Xi(:).';
    Xdot(i, :) = Xidot(:).';
    coordNorm(i) = norm(Xi, 'fro');
end

coord = struct();
coord.kind = 'normal';
coord.Uref = Uref;
coord.n = n;
coord.p = p;
coord.X = X;
coord.Xdot = Xdot;
coord.coordNorm = coordNorm;
end
