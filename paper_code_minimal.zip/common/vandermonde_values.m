function V = vandermonde_values(t, degree)
%VANDERMONDE_VALUES Monomial Vandermonde with columns 1,t,...,t^degree.

t = t(:);
V = ones(numel(t), degree + 1);
for j = 2:degree+1
    V(:, j) = V(:, j-1).*t;
end
end
