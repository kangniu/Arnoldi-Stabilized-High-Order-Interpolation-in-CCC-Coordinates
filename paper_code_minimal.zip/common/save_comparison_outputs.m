function save_comparison_outputs(cfg, prefix, comparison)
%SAVE_COMPARISON_OUTPUTS Write summary, pointwise curves, and MAT data.

if cfg.saveData
    writetable(comparison.summaryTable, ...
        fullfile(cfg.outputTableDir, [prefix, '_summary.csv']));
    writetable(comparison.curveTable, ...
        fullfile(cfg.outputTableDir, [prefix, '_curves.csv']));
    save(fullfile(cfg.outputDataDir, [prefix, '.mat']), 'comparison');
end
end
