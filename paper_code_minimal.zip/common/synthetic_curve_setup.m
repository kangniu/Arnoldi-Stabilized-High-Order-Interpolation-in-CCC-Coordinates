function curve = synthetic_curve_setup(n, p, seed)
%SYNTHETIC_CURVE_SETUP Random transcendental curve from the manuscript.

if nargin < 3
    seed = 1137;
end

state = rng;
rng(seed, 'twister');

curve = struct();
curve.n = n;
curve.p = p;
curve.seed = seed;
curve.Y0 = rand(n, p) - 0.5;
curve.Y1 = rand(n, p) - 0.5;
curve.Y2 = rand(n, p) - 0.5;
curve.Y3 = rand(n, p) - 0.5;

rng(state);
end
