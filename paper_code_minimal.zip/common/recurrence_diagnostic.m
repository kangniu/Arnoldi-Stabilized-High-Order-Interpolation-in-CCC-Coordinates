function cRec = recurrence_diagnostic(PhiAug, H)
%RECURRENCE_DIAGNOSTIC Simple a posteriori CV+A recurrence-growth diagnostic.

subdiag = abs(diag(H, -1));
if isempty(subdiag)
    cRec = max(vecnorm(PhiAug, 2, 2));
    return;
end

localAmp = zeros(numel(subdiag), 1);
for j = 1:numel(subdiag)
    localAmp(j) = (1 + sum(abs(H(1:j, j)))) / max(subdiag(j), realmin);
end

cRec = max(vecnorm(PhiAug, 2, 2)) * max(localAmp);
end
