function Dcell = zero_tangent_cells(Ucell)
%ZERO_TANGENT_CELLS Create zero tangent cells matching Ucell sizes.

Dcell = cell(size(Ucell));
for i = 1:numel(Ucell)
    Dcell{i} = zeros(size(Ucell{i}));
end
end
