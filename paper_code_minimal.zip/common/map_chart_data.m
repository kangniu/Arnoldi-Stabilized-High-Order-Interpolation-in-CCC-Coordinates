function coord = map_chart_data(chart, Ucell, Dcell)
%MAP_CHART_DATA Map Stiefel samples and horizontal lifts to affine coordinates.

m = numel(Ucell);
n = chart.n;
p = chart.p;
q = n - p;

X = zeros(m, q*p);
Xdot = zeros(m, q*p);
kappaF = zeros(m, 1);
kappa2 = zeros(m, 1);
sigmaMin = zeros(m, 1);
coordNorm = zeros(m, 1);

for i = 1:m
    V = apply_chart_transform(chart, Ucell{i});
    W = apply_chart_transform(chart, Dcell{i});

    V1 = V(1:p, :);
    V2 = V(p+1:end, :);
    W1 = W(1:p, :);
    W2 = W(p+1:end, :);

    Xi = V2 / V1;
    Xidot = (W2 - Xi*W1) / V1;

    X(i, :) = Xi(:).';
    Xdot(i, :) = Xidot(:).';

    invV1 = V1 \ eye(p);
    s = svd(V1);
    sigmaMin(i) = min(s);
    kappaF(i) = norm(invV1, 'fro');
    kappa2(i) = norm(invV1, 2);
    coordNorm(i) = norm(Xi, 'fro');
end

coord = struct();
coord.kind = 'chart';
coord.chart = chart;
coord.X = X;
coord.Xdot = Xdot;
coord.kappaF = kappaF;
coord.kappa2 = kappa2;
coord.sigmaMin = sigmaMin;
coord.coordNorm = coordNorm;
end
