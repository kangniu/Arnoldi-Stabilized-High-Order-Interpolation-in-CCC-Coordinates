function arn = cva_arnoldi(t, degree)
%CVA_ARNOLDI Scaled Arnoldi basis for confluent Hermite interpolation.

t = t(:);
m = numel(t);
N = 2*m;
if degree > N - 1
    error('CVA degree %d exceeds the Hermite data dimension %d.', degree, N - 1);
end

Q = zeros(N, degree + 1);
H = zeros(degree + 1, degree);
Q(:, 1) = [ones(m, 1); zeros(m, 1)];

for j = 1:degree
    qTop = Q(1:m, j);
    qBot = Q(m+1:end, j);
    v = [t.*qTop; qTop + t.*qBot];

    for pass = 1:2
        for i = 1:j
            hij = (Q(:, i).'*v) / m;
            H(i, j) = H(i, j) + hij;
            v = v - Q(:, i)*hij;
        end
    end

    hnext = norm(v) / sqrt(m);
    H(j + 1, j) = hnext;
    if hnext <= 100*eps
        warning('cva_arnoldi:Breakdown', ...
            'Near breakdown at step %d; remaining basis columns are set to NaN.', j);
        Q(:, j+1:end) = NaN;
        break;
    end
    Q(:, j + 1) = v / hnext;
end

arn = struct();
arn.Q = Q;
arn.H = H;
arn.degree = degree;
arn.m = m;
arn.etaQ = norm((Q.'*Q)/m - eye(degree + 1), 2);
arn.condQ = cond(Q);
arn.minSubdiag = min(abs(diag(H, -1)));
end
