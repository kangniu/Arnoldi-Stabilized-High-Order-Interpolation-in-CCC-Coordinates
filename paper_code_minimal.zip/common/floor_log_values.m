function y = floor_log_values(x)
%FLOOR_LOG_VALUES Avoid zeros and negative roundoff in logarithmic plots.

y = x(:);
y(~isfinite(y)) = NaN;
y = max(y, 1e-16);
end
