function alg = empty_alg(typeName, degree)
%EMPTY_ALG Placeholder algorithm diagnostics after a failed method.

alg = struct();
alg.type = typeName;
alg.degree = degree;
alg.condSystem = NaN;
alg.coeffNormF = NaN;
alg.etaQ = NaN;
alg.condQ = NaN;
alg.minSubdiag = NaN;
alg.basisGrowth = NaN;
alg.recurrenceDiagnostic = NaN;
end
