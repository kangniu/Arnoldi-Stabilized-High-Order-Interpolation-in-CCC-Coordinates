function [Q, R] = thin_qr_positive(Y)
%THIN_QR_POSITIVE Thin QR with positive diagonal in R when possible.

[Q, R] = qr(Y, 0);
d = sign(diag(R));
d(d == 0) = 1;
D = diag(d);
Q = Q*D;
R = D*R;
end
