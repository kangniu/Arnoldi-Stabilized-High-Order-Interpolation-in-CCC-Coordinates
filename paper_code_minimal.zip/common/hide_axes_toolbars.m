function hide_axes_toolbars(fig)
%HIDE_AXES_TOOLBARS Prevent MATLAB axes toolbars from appearing in exports.

axesHandles = findall(fig, 'Type', 'axes');
for k = 1:numel(axesHandles)
    ax = axesHandles(k);
    if isprop(ax, 'Toolbar') && ~isempty(ax.Toolbar)
        ax.Toolbar.Visible = 'off';
    end
end
end
