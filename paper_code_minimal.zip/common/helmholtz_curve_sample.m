function sample = helmholtz_curve_sample(curve, t)
%HELMHOLTZ_CURVE_SAMPLE Stiefel data for k in [10,20] normalized by t in [0,1].

t = t(:);
m = numel(t);
U = cell(m, 1);
Delta = cell(m, 1);
Y = cell(m, 1);
Ydot = cell(m, 1);
k = curve.kMin + (curve.kMax - curve.kMin)*t;
dkdt = curve.kMax - curve.kMin;
I = speye(curve.n);

for i = 1:m
    A = curve.L - (k(i)^2)*I;
    Yi = A \ curve.F;
    YiPrimeK = A \ (2*k(i)*Yi);
    YiPrimeT = dkdt*YiPrimeK;
    [Ui, Di] = horizontal_lift_from_full_rank(Yi, YiPrimeT);

    U{i} = Ui;
    Delta{i} = Di;
    Y{i} = Yi;
    Ydot{i} = YiPrimeT;
end

sample = struct();
sample.t = t;
sample.k = k;
sample.U = U;
sample.Delta = Delta;
sample.Y = Y;
sample.Ydot = Ydot;
sample.n = curve.n;
sample.p = curve.p;
end
