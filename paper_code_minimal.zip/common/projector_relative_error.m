function err = projector_relative_error(Uhat, Utrue)
%PROJECTOR_RELATIVE_ERROR Relative Frobenius projector error.

if any(~isfinite(Uhat(:))) || any(~isfinite(Utrue(:)))
    err = NaN;
    return;
end

p = size(Utrue, 2);
Qhat = orthonormalize(Uhat);
Qtrue = orthonormalize(Utrue);

% For two p-dimensional subspaces,
% ||Qhat Qhat' - Qtrue Qtrue'||_F = sqrt(2) ||(I-Qtrue Qtrue')Qhat||_F.
% This residual form avoids the severe cancellation in 2p-2||Qhat'Qtrue||_F^2
% when the two subspaces are nearly identical.
residual = Qhat - Qtrue*(Qtrue.'*Qhat);
err = sqrt(2)*norm(residual, 'fro') / sqrt(p);
end
