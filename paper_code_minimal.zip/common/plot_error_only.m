function plot_error_only(tEval, results, titleText, outFile, xLabelText)
%PLOT_ERROR_ONLY Single-panel semilog plot of relative projector error.

if nargin < 5 || isempty(xLabelText)
    xLabelText = 't';
end

fig = figure('Color', 'w', 'Position', [100, 100, 760, 460]);
hold on;
for i = 1:numel(results)
    style = method_plot_style(results(i).name);
    semilogy(tEval, floor_log_values(results(i).error), ...
        'Color', style.Color, 'LineStyle', style.LineStyle, ...
        'LineWidth', style.LineWidth);
end
grid on;
set(gca, 'YScale', 'log');
xlabel(xLabelText);
ylabel('relative projector error');
title(titleText, 'Interpreter', 'none');
legend({results.label}, 'Interpreter', 'none', 'Location', 'southoutside', 'NumColumns', 2);

if nargin >= 4 && ~isempty(outFile)
    hide_axes_toolbars(fig);
    exportgraphics(fig, outFile, 'Resolution', 300);
end
end
