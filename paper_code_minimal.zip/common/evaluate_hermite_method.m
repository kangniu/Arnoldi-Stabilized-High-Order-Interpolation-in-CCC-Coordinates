function result = evaluate_hermite_method(method, tTrain, Utrain, Dtrain, tEval, Utrue, centerIndex)
%EVALUATE_HERMITE_METHOD Fit one Hermite method and evaluate projector error.

if nargin < 7 || isempty(centerIndex)
    centerIndex = ceil(numel(tTrain)/2);
end

tTrain = tTrain(:);
tEval = tEval(:);
Uref = Utrain{centerIndex};
[n, p] = size(Uref);

result = struct();
result.name = method.name;
result.label = method.label;
result.coordType = method.coordType;
result.algebra = method.algebra;
result.tEval = tEval;
result.error = NaN(numel(tEval), 1);
result.orthLoss = NaN(numel(tEval), 1);
result.failure = '';

try
    switch lower(method.coordType)
        case 'normal'
            coord = map_normal_data(Uref, Utrain, Dtrain);
            reconstruct = @(xrow) reconstruct_normal_point(coord, xrow);
        case {'raw', 'maxvol', 'ccc'}
            chart = build_chart(method.coordType, Uref);
            coord = map_chart_data(chart, Utrain, Dtrain);
            reconstruct = @(xrow) reconstruct_chart_point(chart, xrow);
        otherwise
            error('Unknown coordinate type "%s".', method.coordType);
    end

    switch lower(method.algebra)
        case 'direct'
            [Xeval, alg] = hermite_interpolate_direct(tTrain, coord.X, coord.Xdot, tEval);
        case 'cva'
            [Xeval, alg] = hermite_interpolate_cva(tTrain, coord.X, coord.Xdot, tEval);
        otherwise
            error('Unknown algebra type "%s".', method.algebra);
    end

    for j = 1:numel(tEval)
        Uhat = reconstruct(Xeval(j, :));
        result.error(j) = projector_relative_error(Uhat, Utrue{j});
        result.orthLoss(j) = orthogonality_loss(Uhat);
    end

    result.coord = strip_large_coord(coord);
    result.alg = alg;
catch ME
    result.failure = ME.message;
    result.coord = struct();
    result.alg = empty_alg(method.algebra, 2*numel(tTrain)-1);
    warning('evaluate_hermite_method:Failed', ...
        'Method %s failed: %s', method.name, ME.message);
end

result.summary = summarize_method_result(result, n, p, numel(tTrain));
end
