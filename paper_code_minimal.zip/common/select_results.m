function selected = select_results(results, methodNames)
%SELECT_RESULTS Keep results whose names occur in methodNames.

if nargin < 2 || isempty(methodNames)
    selected = results;
    return;
end

keep = false(numel(results), 1);
for i = 1:numel(results)
    keep(i) = any(strcmp(results(i).name, methodNames));
end
selected = results(keep);
end
