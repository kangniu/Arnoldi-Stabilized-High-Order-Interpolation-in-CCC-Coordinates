function light = strip_large_coord(coord)
%STRIP_LARGE_COORD Keep diagnostics but omit large coordinate arrays.

light = coord;
if isfield(light, 'X')
    light = rmfield(light, 'X');
end
if isfield(light, 'Xdot')
    light = rmfield(light, 'Xdot');
end
if isfield(light, 'chart') && isfield(light.chart, 'Q')
    light.chart.Q = [];
end
if isfield(light, 'Uref')
    light.Uref = [];
end
end
