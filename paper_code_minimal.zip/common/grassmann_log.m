function X = grassmann_log(U0, U)
%GRASSMANN_LOG Grassmann logarithm in the horizontal tangent at U0.

M = (U - U0*(U0.'*U)) / (U0.'*U);
[A, S, B] = svd(M, 'econ');
theta = atan(diag(S));
X = A*diag(theta)*B.';
X = X - U0*(U0.'*X);
end
