function sample = synthetic_curve_sample(curve, t, opts)
%SYNTHETIC_CURVE_SAMPLE Stiefel representatives and horizontal derivatives.

if nargin < 3
    opts = struct();
end
if ~isfield(opts, 'noiseLevel')
    opts.noiseLevel = 0;
end
if ~isfield(opts, 'noiseSeed')
    opts.noiseSeed = 2718;
end

t = t(:);
m = numel(t);
U = cell(m, 1);
Delta = cell(m, 1);
Yraw = cell(m, 1);
Yused = cell(m, 1);
Ydot = cell(m, 1);

if opts.noiseLevel > 0
    state = rng;
    rng(opts.noiseSeed, 'twister');
end

for i = 1:m
    [Yi, YiDot] = synthetic_curve_raw(curve, t(i));
    if opts.noiseLevel > 0
        E = 2*rand(size(Yi)) - 1;
        E = E / max(norm(E, 'fro'), realmin);
        YiUsed = Yi + opts.noiseLevel*E;
    else
        YiUsed = Yi;
    end

    [Ui, Di] = horizontal_lift_from_full_rank(YiUsed, YiDot);
    U{i} = Ui;
    Delta{i} = Di;
    Yraw{i} = Yi;
    Yused{i} = YiUsed;
    Ydot{i} = YiDot;
end

if opts.noiseLevel > 0
    rng(state);
end

sample = struct();
sample.t = t;
sample.U = U;
sample.Delta = Delta;
sample.Yraw = Yraw;
sample.Yused = Yused;
sample.Ydot = Ydot;
sample.n = curve.n;
sample.p = curve.p;
sample.noiseLevel = opts.noiseLevel;
end
