function curve = helmholtz_curve_setup(n, p, seed)
%HELMHOLTZ_CURVE_SETUP One-dimensional Helmholtz ROM data generator.

if nargin < 3
    seed = 3141;
end

h = 1/(n + 1);
e = ones(n, 1);
L = spdiags([-e, 2*e, -e], [-1, 0, 1], n, n) / h^2;
x = (1:n).' * h;

centers = linspace(0.15, 0.85, p);
width = 0.035;
F = zeros(n, p);
for j = 1:p
    F(:, j) = exp(-((x - centers(j))/width).^2);
    F(:, j) = F(:, j) / max(norm(F(:, j)), realmin);
end

state = rng;
rng(seed, 'twister');
F = F + 0.02*randn(n, p);
for j = 1:p
    F(:, j) = F(:, j) / max(norm(F(:, j)), realmin);
end
rng(state);

curve = struct();
curve.n = n;
curve.p = p;
curve.seed = seed;
curve.h = h;
curve.x = x;
curve.L = L;
curve.F = F;
curve.kMin = 10;
curve.kMax = 20;
end
