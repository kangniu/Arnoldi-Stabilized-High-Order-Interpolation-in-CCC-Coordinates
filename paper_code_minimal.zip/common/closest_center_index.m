function idx = closest_center_index(t, target)
%CLOSEST_CENTER_INDEX Index of the node closest to target.

if nargin < 2
    target = 0.5;
end
[~, idx] = min(abs(t(:) - target));
end
