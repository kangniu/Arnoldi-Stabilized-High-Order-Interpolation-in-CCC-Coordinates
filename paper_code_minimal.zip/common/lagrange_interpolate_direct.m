function [Xeval, alg] = lagrange_interpolate_direct(t, X, s)
%LAGRANGE_INTERPOLATE_DIRECT Direct monomial Vandermonde interpolation.

t = t(:);
s = s(:);
degree = numel(t) - 1;
Vtrain = vandermonde_values(t, degree);
coef = Vtrain \ X;
Veval = vandermonde_values(s, degree);
Xeval = Veval * coef;

alg = struct();
alg.type = 'direct-lagrange';
alg.degree = degree;
alg.condSystem = cond(Vtrain);
alg.coeffNormF = norm(coef, 'fro');
alg.etaQ = NaN;
alg.condQ = NaN;
alg.minSubdiag = NaN;
alg.basisGrowth = max(vecnorm(Veval, 2, 2));
alg.recurrenceDiagnostic = NaN;
end
