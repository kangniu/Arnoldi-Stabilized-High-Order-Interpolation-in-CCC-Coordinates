function [Y, Ydot] = synthetic_curve_raw(curve, t)
%SYNTHETIC_CURVE_RAW Evaluate Y(t) and dY/dt for the synthetic curve.

Y = curve.Y0 + sin(3*t)*curve.Y1 + cos(3*t)*curve.Y2 + exp(t)*curve.Y3;
Ydot = 3*cos(3*t)*curve.Y1 - 3*sin(3*t)*curve.Y2 + exp(t)*curve.Y3;
end
