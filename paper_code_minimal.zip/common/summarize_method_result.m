function row = summarize_method_result(result, n, p, m)
%SUMMARIZE_METHOD_RESULT One-row diagnostics for a method result.

row = struct();
row.Method = result.name;
row.Label = result.label;
row.CoordType = result.coordType;
row.Algebra = result.algebra;
row.n = n;
row.p = p;
row.Nodes = m;
row.Degree = result.alg.degree;
row.MaxError = max(result.error, [], 'omitnan');
row.MedianError = median(result.error, 'omitnan');
row.MaxOrthogonalityLoss = max(result.orthLoss, [], 'omitnan');
row.ConfluentVandermondeCondition = result.alg.condSystem;
row.ArnoldiEtaQ = result.alg.etaQ;
row.ArnoldiCondQ = result.alg.condQ;
row.MinSubdiagonal = result.alg.minSubdiag;
row.BasisGrowth = result.alg.basisGrowth;
row.RecurrenceDiagnostic = result.alg.recurrenceDiagnostic;
row.CoefficientNormF = result.alg.coeffNormF;
row.Failure = result.failure;

if isfield(result.coord, 'kappaF')
    row.MaxChartKappaF = max(result.coord.kappaF, [], 'omitnan');
    row.MaxChartKappa2 = max(result.coord.kappa2, [], 'omitnan');
    row.MinChartSigma = min(result.coord.sigmaMin, [], 'omitnan');
else
    row.MaxChartKappaF = NaN;
    row.MaxChartKappa2 = NaN;
    row.MinChartSigma = NaN;
end

if isfield(result.coord, 'coordNorm')
    row.MaxCoordinateNormF = max(result.coord.coordNorm, [], 'omitnan');
else
    row.MaxCoordinateNormF = NaN;
end
end
