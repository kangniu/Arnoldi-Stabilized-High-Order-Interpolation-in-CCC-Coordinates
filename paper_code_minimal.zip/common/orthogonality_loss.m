function loss = orthogonality_loss(U)
%ORTHOGONALITY_LOSS Frobenius Stiefel orthogonality residual.

if any(~isfinite(U(:)))
    loss = NaN;
    return;
end

p = size(U, 2);
loss = norm(U.'*U - eye(p), 'fro');
end
