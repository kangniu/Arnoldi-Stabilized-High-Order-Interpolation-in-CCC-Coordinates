function U = reconstruct_chart_point(chart, xrow)
%RECONSTRUCT_CHART_POINT Reconstruct a Stiefel representative from chart data.

p = chart.p;
q = chart.n - chart.p;
Xi = reshape(xrow(:), q, p);

if any(~isfinite(Xi(:)))
    U = NaN(chart.n, chart.p);
    return;
end

A = [eye(p); Xi];
try
    R = chol(eye(p) + Xi.'*Xi);
    V = A / R;
catch
    [V, ~] = thin_qr_positive(A);
end

U = apply_chart_inverse(chart, V);
end
