function U = apply_chart_inverse(chart, V)
%APPLY_CHART_INVERSE Map a chart-adapted representative back to original rows.

switch chart.type
    case {'raw', 'maxvol'}
        U = zeros(chart.n, chart.p);
        U(chart.perm, :) = V;
    case 'ccc'
        U = chart.Q * V;
    otherwise
        error('Unknown chart type "%s".', chart.type);
end
end
