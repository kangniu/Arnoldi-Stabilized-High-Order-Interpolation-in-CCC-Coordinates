function Phi = eval_arnoldi_basis(s, H)
%EVAL_ARNOLDI_BASIS Evaluate a V+A scalar basis from Hessenberg coefficients.

s = s(:);
M = numel(s);
degree = size(H, 2);
Phi = zeros(M, degree + 1);
Phi(:, 1) = ones(M, 1);

for j = 1:degree
    v = s.*Phi(:, j) - Phi(:, 1:j)*H(1:j, j);
    hnext = H(j + 1, j);
    if abs(hnext) <= realmin
        Phi(:, j+1:end) = NaN;
        break;
    end
    Phi(:, j + 1) = v / hnext;
end
end
