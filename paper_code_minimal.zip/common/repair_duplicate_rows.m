function selected = repair_duplicate_rows(A, selected)
%REPAIR_DUPLICATE_ROWS Replace duplicate selected rows by leverage candidates.

[n, p] = size(A);
if numel(unique(selected)) == p
    return;
end

used = false(n, 1);
fixed = zeros(1, p);
for j = 1:p
    idx = selected(j);
    if idx >= 1 && idx <= n && ~used(idx)
        fixed(j) = idx;
        used(idx) = true;
    end
end

scores = sum(abs(A), 2);
[~, order] = sort(scores, 'descend');
for j = 1:p
    if fixed(j) ~= 0
        continue;
    end
    replacement = order(find(~used(order), 1, 'first'));
    fixed(j) = replacement;
    used(replacement) = true;
end

selected = fixed;
end
