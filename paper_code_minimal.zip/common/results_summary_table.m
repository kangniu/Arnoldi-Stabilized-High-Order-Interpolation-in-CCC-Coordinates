function T = results_summary_table(results)
%RESULTS_SUMMARY_TABLE Convert method summaries to a MATLAB table.

n = numel(results);
S = repmat(results(1).summary, n, 1);
for i = 1:n
    S(i) = results(i).summary;
end
T = struct2table(S);
end
