function [Xeval, alg] = hermite_interpolate_direct(t, X, Xdot, s)
%HERMITE_INTERPOLATE_DIRECT Direct monomial confluent Vandermonde solve.

t = t(:);
s = s(:);
degree = 2*numel(t) - 1;
C = confluent_vandermonde(t, degree);
Y = [X; Xdot];

coef = C \ Y;
V = vandermonde_values(s, degree);
Xeval = V * coef;

alg = struct();
alg.type = 'direct';
alg.degree = degree;
alg.condSystem = cond(C);
alg.coeffNormF = norm(coef, 'fro');
alg.etaQ = NaN;
alg.condQ = NaN;
alg.minSubdiag = NaN;
alg.basisGrowth = max(vecnorm(V, 2, 2));
alg.recurrenceDiagnostic = NaN;
end
