function V = apply_chart_transform(chart, U)
%APPLY_CHART_TRANSFORM Transform a Stiefel/tangent matrix into chart rows.

switch chart.type
    case {'raw', 'maxvol'}
        V = U(chart.perm, :);
    case 'ccc'
        V = chart.Q.' * U;
    otherwise
        error('Unknown chart type "%s".', chart.type);
end
end
