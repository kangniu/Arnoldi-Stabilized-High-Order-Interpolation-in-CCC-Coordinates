function cfg = default_experiment_config(matlabRoot)
%DEFAULT_EXPERIMENT_CONFIG Shared settings and output locations.

if nargin < 1 || isempty(matlabRoot)
    matlabRoot = fileparts(fileparts(mfilename('fullpath')));
end

cfg = struct();
cfg.seed = 20260716;
cfg.syntheticSeed = 1137;
cfg.noiseSeed = 2718;
cfg.helmholtzSeed = 3141;
cfg.evalPoints = 200;
cfg.makePlots = true;
cfg.saveData = true;
cfg.writePaperFigures = false;

cfg.matlabRoot = matlabRoot;
cfg.projectRoot = fileparts(matlabRoot);
cfg.outputDir = fullfile(matlabRoot, 'output');
cfg.outputFigureDir = fullfile(cfg.outputDir, 'figures');
cfg.outputTableDir = fullfile(cfg.outputDir, 'tables');
cfg.outputDataDir = fullfile(cfg.outputDir, 'data');

ensure_dir(cfg.outputDir);
ensure_dir(cfg.outputFigureDir);
ensure_dir(cfg.outputTableDir);
ensure_dir(cfg.outputDataDir);
end
