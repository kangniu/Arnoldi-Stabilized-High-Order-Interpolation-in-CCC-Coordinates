function [Xeval, alg] = hermite_interpolate_cva(t, X, Xdot, s)
%HERMITE_INTERPOLATE_CVA Confluent V+A interpolation for many RHS columns.

t = t(:);
s = s(:);
degree = 2*numel(t) - 1;
arn = cva_arnoldi(t, degree);
Y = [X; Xdot];

A = arn.Q \ Y;
[PhiValue, ~, PhiAug] = eval_augmented_basis(s, arn.H);
Xeval = PhiValue * A;

alg = struct();
alg.type = 'cva';
alg.degree = degree;
alg.condSystem = NaN;
alg.coeffNormF = norm(A, 'fro');
alg.etaQ = arn.etaQ;
alg.condQ = arn.condQ;
alg.minSubdiag = arn.minSubdiag;
alg.basisGrowth = max(vecnorm(PhiValue, 2, 2));
alg.recurrenceDiagnostic = recurrence_diagnostic(PhiAug, arn.H);
alg.H = arn.H;
end
