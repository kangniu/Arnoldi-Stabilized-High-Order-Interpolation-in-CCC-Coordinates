%RUN_ALL_EXPERIMENTS Reproduce the numerical comparisons in the manuscript.
%
% The script writes figures, CSV summaries, and MAT files under
% matlab/output/.  It does not overwrite the paper figures in the project
% root unless cfg.writePaperFigures is set to true below.

clear; close all; clc;

matlabRoot = fileparts(mfilename('fullpath'));
addpath(fullfile(matlabRoot, 'common'));
addpath(fullfile(matlabRoot, 'experiments'));

cfg = default_experiment_config(matlabRoot);
cfg.writePaperFigures = false;  % Set true to overwrite root PNGs used by main.tex.
cfg.makePlots = true;
cfg.saveData = true;

rng(cfg.seed, 'twister');

fprintf('Running all Grassmann interpolation experiments...\n');
fprintf('Output directory: %s\n\n', cfg.outputDir);

resultsExample1 = run_example1_dual_stability(cfg);
resultsExample2 = run_example2_noise(cfg);
resultsExample3 = run_example3_helmholtz_rom(cfg);

if cfg.saveData
    save(fullfile(cfg.outputDataDir, 'all_experiment_results.mat'), ...
        'cfg', 'resultsExample1', 'resultsExample2', 'resultsExample3');
end

fprintf('\nFinished all experiments.\n');
